---
classes: wide
title: Dimensionality reduction vs. compression
tags: ml tensorflow
header:
    teaser: "assets/posts/stan/.png"
excerpt_separator: <!--more-->
---

<!--more-->

---
classes: wide
---

ideas:
    - [x] distances between positive definite matrices
    - [ ] top10 20th century
    - [x] randomized algos for approximate matrix decomposition
    - [x] SGMCMC
    - Julia	
    - [x] pivae
    - [ ] PCA
    - C++
      - [x] build a neural net
      - [x] open source

---
classes: wide
title: I defended my PhD thesis!
tags: talk ml adaptation wasserstein
header:
    teaser: "assets/posts/phd/thumbnail.png"
excerpt_separator: <!--more-->
---
Youtube recording of my PhD thesis defense at NYU Center for Neural Science.
<!--more-->

<iframe width="1280" height="720" src="https://www.youtube.com/embed/R50yEhZWR6w" title="Lyndon Duong PhD Defense: Adaptive Coding Efficiency &amp; Stochastic Geometry" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
